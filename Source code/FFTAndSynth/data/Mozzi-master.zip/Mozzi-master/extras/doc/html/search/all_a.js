var searchData=
[
  ['operator_20stereooutput',['operator StereoOutput',['../struct_mono_output.html#aca2b1f7d1c71c21743827ea1f0040ec4',1,'MonoOutput']]],
  ['operator_28_29',['operator()',['../class_auto_map.html#afd49885d3f05ca0a2f417199a9e7cf10',1,'AutoMap::operator()()'],['../class_int_map.html#ae3bf8b61f2ab79ac6626245213e7cb2a',1,'IntMap::operator()()'],['../class_smooth.html#a24eb02e4c4bfe9401f24ed0399b1e392',1,'Smooth::operator()()']]],
  ['oscil',['Oscil',['../class_oscil.html',1,'Oscil&lt; NUM_TABLE_CELLS, UPDATE_RATE &gt;'],['../class_oscil.html#afe6a75646d2dd822a654bcd85242e800',1,'Oscil::Oscil(const int8_t *TABLE_NAME)'],['../class_oscil.html#ab7dc5f97742d841fff6a4dca6d7242f3',1,'Oscil::Oscil()']]],
  ['oscil_3c_208192_2c_20audio_5frate_20_3e',['Oscil&lt; 8192, AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oscil_3c_20cos8192_5fnum_5fcells_2c_20audio_5frate_20_3e',['Oscil&lt; COS8192_NUM_CELLS, AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oscil_3c_20sin2048_5fnum_5fcells_2c_20audio_5frate_20_3e',['Oscil&lt; SIN2048_NUM_CELLS, AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oversample',['OverSample',['../class_over_sample.html',1,'']]]
];
